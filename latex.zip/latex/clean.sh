#!/bin/sh
RESULT_DIR="result"
OUTPUT_DIR="../temp"
FILE="thesis"
cd tex
rm -rf $OUTPUT_DIR
cd ..
rm -rf $RESULT_DIR
